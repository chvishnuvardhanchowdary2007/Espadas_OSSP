#define _GNU_SOURCE
#include <ncurses.h>
#include <dirent.h>
#include <ctype.h>
#include <unistd.h>
#include <pwd.h>
#include <signal.h>
#include <sys/statvfs.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <time.h>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define MAX_PROCS 4096
#define HIST 120

typedef struct { int pid; char user[32], command[256], state; double cpu, mem; unsigned long long ticks; } Process;
typedef struct { unsigned long long rx, tx; } NetTotals;
static volatile sig_atomic_t resized = 0;
static void on_resize(int sig) { (void)sig; resized = 1; }
static double cpu_usage = 0, cpu_hist[HIST]; static int cpu_n=0;
static unsigned long long prev_total=0, prev_idle=0;
static Process procs[MAX_PROCS], previous_procs[MAX_PROCS]; static int proc_count=0, previous_count=0;
static int sort_mode=0;
static unsigned long long prev_rx=0, prev_tx=0; static double rx_rate=0, tx_rate=0;

static void history_add(double *a,int *n,double v){ if(*n<HIST) a[(*n)++]=v; else { memmove(a,a+1,(HIST-1)*sizeof(double)); a[HIST-1]=v; } }
static void get_cpu(void){ FILE*f=fopen("/proc/stat","r"); if(!f)return; char line[512]; unsigned long long u,n,s,id,iw,irq,soft,steal; if(fgets(line,sizeof line,f)&&sscanf(line,"cpu %llu %llu %llu %llu %llu %llu %llu %llu",&u,&n,&s,&id,&iw,&irq,&soft,&steal)>=4){ unsigned long long idle=id+iw,total=u+n+s+id+iw+irq+soft+steal; if(prev_total){ unsigned long long dt=total-prev_total,di=idle-prev_idle; cpu_usage=dt?100.0*(dt-di)/dt:0; } prev_total=total;prev_idle=idle;history_add(cpu_hist,&cpu_n,cpu_usage);} fclose(f); }
static void get_memory(double *total,double *used,double *avail,double *swap_total,double *swap_used){ FILE*f=fopen("/proc/meminfo","r"); char key[64],unit[16]; double val; *total=*used=*avail=*swap_total=*swap_used=0; if(!f)return; while(fscanf(f,"%63s %lf %15s",key,&val,unit)==3){ if(!strcmp(key,"MemTotal:"))*total=val; else if(!strcmp(key,"MemAvailable:"))*avail=val; else if(!strcmp(key,"SwapTotal:"))*swap_total=val; else if(!strcmp(key,"SwapFree:"))*swap_used=*swap_total-val; } fclose(f); *used=*total-*avail; if(*used<0)*used=0; }
static void get_network(void){ FILE*f=fopen("/proc/net/dev","r"); char line[512],name[64]; unsigned long long r, rp,re,rd,rf, rfr,rc,rm,t,tp,te,td,tf,tco,tc,ts; unsigned long long sr=0,st=0; if(!f)return; fgets(line,sizeof line,f);fgets(line,sizeof line,f); while(fgets(line,sizeof line,f)){ char *c=strchr(line,':'); if(!c)continue; *c='\0'; snprintf(name,sizeof name,"%s",line); char *p=name;while(isspace((unsigned char)*p))p++; if(!strcmp(p,"lo"))continue; if(sscanf(c+1,"%llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu",&r,&rp,&re,&rd,&rf,&rfr,&rc,&rm,&t,&tp,&te,&td,&tf,&tco,&tc,&ts)>=9){sr+=r;st+=t;} } fclose(f); rx_rate=prev_rx?(double)(sr-prev_rx):0; tx_rate=prev_tx?(double)(st-prev_tx):0; prev_rx=sr;prev_tx=st; }
static int cmp_cpu(const void*a,const void*b){const Process*x=a,*y=b;return x->cpu<y->cpu?1:x->cpu>y->cpu?-1:0;}
static int cmp_mem(const void*a,const void*b){const Process*x=a,*y=b;return x->mem<y->mem?1:x->mem>y->mem?-1:0;}
static int cmp_pid(const void*a,const void*b){return ((const Process*)a)->pid-((const Process*)b)->pid;}
static void get_processes(double elapsed){ DIR*d=opendir("/proc"); struct dirent*e; proc_count=0;if(!d)return; while((e=readdir(d))&&proc_count<MAX_PROCS){ if(!isdigit((unsigned char)e->d_name[0]))continue; int pid=atoi(e->d_name); char path[256],line[4096],comm[256]="?",state='?'; unsigned long long ut=0,st=0; long rss=0; unsigned uid=0; snprintf(path,sizeof path,"/proc/%d/stat",pid); FILE*f=fopen(path,"r");if(!f)continue;if(!fgets(line,sizeof line,f)){fclose(f);continue;}fclose(f); char *a=strchr(line,'('),*b=strrchr(line,')');if(!a||!b)continue;size_t len=(size_t)(b-a-1);if(len>255)len=255;memcpy(comm,a+1,len);comm[len]='\0'; if(sscanf(b+2,"%c %*d %*d %*d %*d %*d %*u %*lu %*lu %*lu %*lu %llu %llu",&state,&ut,&st)<3)continue;
 unsigned long long ticks=ut+st; double cpu=0; for(int k=0;k<previous_count;k++){if(previous_procs[k].pid==pid){unsigned long long delta=ticks>=previous_procs[k].ticks?ticks-previous_procs[k].ticks:0; long hz=sysconf(_SC_CLK_TCK); cpu=(elapsed>0&&hz>0)?100.0*(double)delta/(double)hz/elapsed:0; break;}}
 snprintf(path,sizeof path,"/proc/%d/status",pid);f=fopen(path,"r");if(f){while(fgets(line,sizeof line,f)){if(sscanf(line,"Uid: %u",&uid)==1){} if(sscanf(line,"VmRSS: %ld",&rss)==1){}}fclose(f);} struct passwd*pw=getpwuid(uid); Process*p=&procs[proc_count++];p->pid=pid;p->cpu=cpu;p->mem=rss/1024.0;p->state=state;p->ticks=ticks;snprintf(p->user,sizeof p->user,"%s",pw?pw->pw_name:"?");snprintf(p->command,sizeof p->command,"[%s]",comm);snprintf(path,sizeof path,"/proc/%d/cmdline",pid);f=fopen(path,"r");if(f){size_t z=fread(p->command,1,sizeof(p->command)-1,f);fclose(f);if(z){p->command[z]='\0';for(size_t i=0;i<z;i++)if(!p->command[i])p->command[i]=' ';}} }
 closedir(d); memcpy(previous_procs,procs,(size_t)proc_count*sizeof(Process)); previous_count=proc_count; if(sort_mode==0)qsort(procs,proc_count,sizeof(Process),cmp_cpu);else if(sort_mode==1)qsort(procs,proc_count,sizeof(Process),cmp_mem);else qsort(procs,proc_count,sizeof(Process),cmp_pid); }
static void colors(void){start_color();use_default_colors();init_pair(1,COLOR_CYAN,-1);init_pair(2,COLOR_WHITE,-1);init_pair(3,COLOR_GREEN,-1);init_pair(4,COLOR_YELLOW,-1);init_pair(5,COLOR_RED,-1);init_pair(6,COLOR_BLACK,COLOR_CYAN);}
static void titled(WINDOW*w,const char*s){wattron(w,COLOR_PAIR(1));box(w,0,0);wattroff(w,COLOR_PAIR(1));wattron(w,COLOR_PAIR(2)|A_BOLD);mvwprintw(w,0,2," %s ",s);wattroff(w,COLOR_PAIR(2)|A_BOLD);}
static void gauge(WINDOW*w,int y,int x,int width,double pct){if(width<4)return;if(pct<0)pct=0;if(pct>100)pct=100;int n=(int)((width-7)*pct/100.0);int cp=pct>=85?5:pct>=60?4:3;wattron(w,COLOR_PAIR(cp));mvwaddch(w,y,x,'[');for(int i=0;i<width-7;i++)mvwaddch(w,y,x+1+i,i<n?'#':' ');mvwaddch(w,y,x+width-6,']');wattroff(w,COLOR_PAIR(cp));mvwprintw(w,y,x+width-5,"%3.0f%%",pct);}
static void panel_cpu(WINDOW*w){werase(w);titled(w,"CPU");int h,ww;getmaxyx(w,h,ww);mvwprintw(w,1,2,"Overall usage");gauge(w,2,2,ww-4,cpu_usage);mvwprintw(w,4,2,"Load average: ");FILE*f=fopen("/proc/loadavg","r");double a=0,b=0,c=0;if(f){fscanf(f,"%lf %lf %lf",&a,&b,&c);fclose(f);}wprintw(w,"%.2f  %.2f  %.2f",a,b,c);mvwprintw(w,6,2,"Recent usage: ");for(int i=0;i<cpu_n&&i<ww-18;i++){int cp=cpu_hist[i]>=85?5:cpu_hist[i]>=60?4:3;wattron(w,COLOR_PAIR(cp));mvwaddch(w,6,18+i,cpu_hist[i]>70?'#':cpu_hist[i]>35?'+':'.');wattroff(w,COLOR_PAIR(cp));}}
static void panel_mem(WINDOW*w){double t,u,a,st,su;get_memory(&t,&u,&a,&st,&su);werase(w);titled(w,"MEMORY");int h,ww;getmaxyx(w,h,ww);mvwprintw(w,1,2,"RAM: %.1f / %.1f GB",u/1048576.0,t/1048576.0);gauge(w,2,2,ww-4,t?u*100/t:0);mvwprintw(w,4,2,"Available: %.1f GB",a/1048576.0);mvwprintw(w,5,2,"Swap: %.1f / %.1f GB",su/1048576.0,st/1048576.0);}
static void panel_disk(WINDOW*w){werase(w);titled(w,"DISK");int h,ww;getmaxyx(w,h,ww);struct statvfs v;if(statvfs("/",&v)==0){double total=(double)v.f_blocks*v.f_frsize,freeb=(double)v.f_bavail*v.f_frsize,used=total-freeb;mvwprintw(w,1,2,"Root filesystem: /");mvwprintw(w,2,2,"Used %.1f / %.1f GB",used/1e9,total/1e9);gauge(w,3,2,ww-4,total?used*100/total:0);}else mvwprintw(w,1,2,"Disk information unavailable");mvwprintw(w,5,2,"Disk space from statvfs()");}
static void panel_net(WINDOW*w){werase(w);titled(w,"NETWORK");int h,ww;getmaxyx(w,h,ww);mvwprintw(w,1,2,"Download: %.1f KB/s",rx_rate/1024.0);mvwprintw(w,2,2,"Upload:   %.1f KB/s",tx_rate/1024.0);mvwprintw(w,4,2,"Rates sampled from /proc/net/dev");}
static void panel_proc(WINDOW*w,int offset){werase(w);const char*label=sort_mode==0?"CPU":sort_mode==1?"MEM":"PID";char title[64];snprintf(title,sizeof title,"PROCESSES (sort: %s)",label);titled(w,title);int h,ww;getmaxyx(w,h,ww);mvwprintw(w,1,1," PID    USER       CPU%%   MEM(MB)  COMMAND");int rows=h-3;if(offset<0)offset=0;if(offset>proc_count-rows)offset=proc_count-rows;if(offset<0)offset=0;for(int i=offset;i<proc_count&&i<offset+rows;i++){Process*p=&procs[i];mvwprintw(w,2+i-offset,1,"%-6d %-10.10s %6.1f %8.1f  %.100s",p->pid,p->user,p->cpu,p->mem,p->command);}}
static void header(WINDOW*w){werase(w);int h,ww;getmaxyx(w,h,ww);char host[128]="linux";gethostname(host,sizeof(host)-1);struct sysinfo si;long up=0;if(sysinfo(&si)==0)up=si.uptime;wattron(w,COLOR_PAIR(6));for(int x=0;x<ww;x++)mvwaddch(w,0,x,' ');mvwprintw(w,0,1," LINUX SYSTEM MONITOR | %s | uptime %ldh %ldm | q quit | c/m/p sort",host,up/3600,(up%3600)/60);wattroff(w,COLOR_PAIR(6));}
int main(void){setlocale(LC_ALL,"");signal(SIGWINCH,on_resize);initscr();noecho();cbreak();curs_set(0);keypad(stdscr,TRUE);timeout(1000);if(has_colors())colors();int offset=0,ch;time_t last=time(NULL);while(1){if(resized){endwin();refresh();clear();resized=0;}time_t now=time(NULL);double elapsed=difftime(now,last);if(elapsed<=0)elapsed=1;last=now;get_cpu();get_network();get_processes(elapsed);int H,W;getmaxyx(stdscr,H,W);int head=1,top=(H-1)*42/100,mid=(H-1)*30/100,bot=H-1-top-mid;if(top<6)top=6;if(mid<5)mid=5;if(bot<5)bot=5;int left=W/2;WINDOW*wh=newwin(head,W,0,0),*wc=newwin(top,W,1,0),*wm=newwin(mid,left,1+top,0),*wd=newwin(mid,W-left,1+top,left),*wn=newwin(bot,W*32/100,1+top+mid,0),*wp=newwin(bot,W-W*32/100,1+top+mid,W*32/100);header(wh);panel_cpu(wc);panel_mem(wm);panel_disk(wd);panel_net(wn);panel_proc(wp,offset);wnoutrefresh(wh);wnoutrefresh(wc);wnoutrefresh(wm);wnoutrefresh(wd);wnoutrefresh(wn);wnoutrefresh(wp);doupdate();delwin(wh);delwin(wc);delwin(wm);delwin(wd);delwin(wn);delwin(wp);ch=getch();if(ch=='q'||ch=='Q')break;else if(ch=='c')sort_mode=0;else if(ch=='m')sort_mode=1;else if(ch=='p')sort_mode=2;else if(ch==KEY_DOWN||ch=='j')offset++;else if(ch==KEY_UP||ch=='k'){if(offset>0)offset--;}}
endwin();return 0;}
